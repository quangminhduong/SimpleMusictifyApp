import boto3
import json
import re

def lambda_handler(event, context):
    title = event['title']
    year = event.get('release_year')
    artist = event['artist']

    if not title and not year and not artist:
        return {
            'statusCode': 400,
            'body': json.dumps({'success': False, 'message': 'Please enter data in at least one of the fields.'})
        }

    dynamodb = boto3.resource('dynamodb')
    music_table = dynamodb.Table('music')

    filters = []
    values = {}

    if title:
        filters.append("contains(title, :title)")
        values[':title'] = title

    if year:
        filters.append("contains(release_year, :release_year)")
        values[':release_year'] = year

    if artist:
        filters.append("contains(artist, :artist)")
        values[':artist'] = artist

    filter_expression = " OR ".join(filters)

    response = music_table.scan(
        FilterExpression=filter_expression,
        ExpressionAttributeValues=values
    )

    items = response['Items']
    for item in items:
        artist_name = item['artist']
        artist_img = ''.join(x.capitalize() for x in re.split(r'[\W_]+', artist_name) if x)
        item['artist_img'] = "https://trapforment.s3.ap-southeast-2.amazonaws.com/"+artist_img+".jpg"

    message = ''
    if not items:
        message = 'No result is retrieved. Please query again.'

    return {
        'statusCode': 200,
        'body': json.dumps({
            'success': True,
            'items': items,
            'message': message
        })
    }
